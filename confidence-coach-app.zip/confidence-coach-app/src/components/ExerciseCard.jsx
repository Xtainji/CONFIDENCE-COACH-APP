export default function ExerciseCard({ title, description, onStart }) {
  return (
    <div className="rounded-2xl bg-white shadow-sm p-6 space-y-3">
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-gray-600 text-sm">{description}</p>
      <button
        onClick={onStart}
        className="mt-2 px-4 py-2 rounded-xl text-white font-medium"
        style={{ backgroundColor: "var(--brand-primary)" }}
      >
        Start Exercise
      </button>
    </div>
  );
}

import { useState } from "react";

// Simple in-memory streak hook.
// Swap this out for persistent storage (database, localStorage-equivalent, etc.)
// when connecting this template to a real backend.
export function useStreak(initialStreak = 0) {
  const [streak, setStreak] = useState(initialStreak);

  const incrementStreak = () => setStreak((prev) => prev + 1);
  const resetStreak = () => setStreak(0);

  return { streak, incrementStreak, resetStreak };
}

// 🔒 Serverless API Route: /api/feedback
// Runs on Vercel (or any Node serverless host). Keeps your Anthropic API key
// server-side and safe — never expose it in client code.
//
// Setup:
// 1. Get an API key from https://console.anthropic.com
// 2. Add it as an environment variable named ANTHROPIC_API_KEY
//    (Vercel: Project → Settings → Environment Variables)

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { transcript } = req.body || {};

  if (!transcript || typeof transcript !== "string") {
    return res.status(400).json({ error: "Missing 'transcript' in request body" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return res.status(500).json({
      error:
        "Server is missing ANTHROPIC_API_KEY. Add it in your hosting provider's environment variables.",
    });
  }

  const systemPrompt = `You are an expert confidence and public-speaking coach.
A user has just recorded themselves speaking. You will receive the transcript
of what they said (not audio) — evaluate their word choice, structure, and
apparent confidence based on the text alone.

Respond ONLY with valid JSON in exactly this shape, nothing else:
{
  "clarity": "<one short phrase, e.g. 'Strong' or 'Needs work'>",
  "tone": "<one short phrase describing tone, e.g. 'Confident' or 'Hesitant'>",
  "confidenceScore": <integer 1-100>,
  "tip": "<one specific, encouraging, actionable tip, max 2 sentences>"
}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        system: systemPrompt,
        messages: [
          {
            role: "user",
            content: `Here is the transcript to evaluate:\n\n"${transcript}"`,
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(502).json({ error: `Anthropic API error: ${errText}` });
    }

    const data = await response.json();
    const rawText = data.content
      ? data.content.map((block) => block.text || "").join("")
      : "";

    let feedback;
    try {
      const cleaned = rawText.replace(/```json|```/g, "").trim();
      feedback = JSON.parse(cleaned);
    } catch {
      // Fallback if the model didn't return clean JSON
      feedback = {
        clarity: "Unavailable",
        tone: "Unavailable",
        confidenceScore: null,
        tip: "Couldn't parse AI response. Try again in a moment.",
      };
    }

    return res.status(200).json(feedback);
  } catch (err) {
    return res.status(500).json({ error: err.message || "Unknown server error" });
  }
}

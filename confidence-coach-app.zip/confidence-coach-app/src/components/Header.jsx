import config from "../config";

export default function Header() {
  return (
    <header className="flex items-center justify-between px-6 py-4 bg-white shadow-sm">
      <div className="flex items-center gap-3">
        <img
          src={config.logo}
          alt={config.appName}
          className="h-8 w-8 rounded-full object-cover"
          onError={(e) => (e.target.style.display = "none")}
        />
        <span className="text-lg font-semibold" style={{ color: "var(--brand-primary)" }}>
          {config.appName}
        </span>
      </div>
    </header>
  );
}

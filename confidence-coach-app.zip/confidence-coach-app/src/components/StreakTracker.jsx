export default function StreakTracker({ streak = 0 }) {
  return (
    <div className="rounded-2xl bg-white shadow-sm p-5 flex items-center justify-between">
      <div>
        <p className="text-sm text-gray-500">Current Streak</p>
        <p className="text-3xl font-bold" style={{ color: "var(--brand-secondary)" }}>
          {streak} days
        </p>
      </div>
      <span className="text-4xl">🔥</span>
    </div>
  );
}

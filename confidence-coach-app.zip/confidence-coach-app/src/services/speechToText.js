// 🎙️ Speech-to-Text Service
// Uses the browser's native Web Speech API — no API key or paid service required.
// Supported in Chrome, Edge, and most Chromium-based browsers.
// (Safari/Firefox support is limited — consider a fallback provider like
// AssemblyAI or Whisper if you need broader browser support.)

export function isSpeechRecognitionSupported() {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function createSpeechRecognizer({ onResult, onEnd, onError }) {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    onError?.(
      new Error(
        "Speech recognition isn't supported in this browser. Try Chrome or Edge."
      )
    );
    return null;
  }

  const recognizer = new SpeechRecognition();
  recognizer.continuous = false;
  recognizer.interimResults = false;
  recognizer.lang = "en-US";

  recognizer.onresult = (event) => {
    const transcript = Array.from(event.results)
      .map((result) => result[0].transcript)
      .join(" ");
    onResult?.(transcript);
  };

  recognizer.onerror = (event) => {
    onError?.(new Error(event.error || "Speech recognition error"));
  };

  recognizer.onend = () => {
    onEnd?.();
  };

  return recognizer;
}

// 🎨 WHITE-LABEL CONFIG
// Edit these values to rebrand the entire app — no other files need to change.

export const config = {
  appName: "Confidence Coach",
  logo: "/assets/logo.png",
  primaryColor: "#6C5CE7",
  secondaryColor: "#00CEC9",
  supportContact: {
    whatsapp: "[YOUR NUMBER]",
    email: "[YOUR EMAIL]",
  },
};

export default config;

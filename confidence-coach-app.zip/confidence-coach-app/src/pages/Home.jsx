import Header from "../components/Header";
import StreakTracker from "../components/StreakTracker";
import ExerciseCard from "../components/ExerciseCard";
import VoiceFeedback from "../components/VoiceFeedback";
import { useStreak } from "../hooks/useStreak";
import config from "../config";

const dailyExercises = [
  {
    title: "Power Pose & Speak",
    description:
      "Stand tall for 60 seconds, then record yourself introducing your biggest goal out loud.",
  },
  {
    title: "Compliment Delivery",
    description:
      "Practice giving and receiving a compliment naturally, without deflecting.",
  },
  {
    title: "Impromptu 30-Second Pitch",
    description:
      "Pick any random object nearby and pitch it like it's the best product in the world.",
  },
];

export default function Home() {
  const { streak, incrementStreak } = useStreak(4);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="max-w-3xl mx-auto px-6 py-8 space-y-8">
        <section>
          <h1 className="text-2xl font-bold mb-1">Welcome back 👋</h1>
          <p className="text-gray-600">
            Let's build your confidence, one day at a time.
          </p>
        </section>

        <StreakTracker streak={streak} />

        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Today's Exercises</h2>
          {dailyExercises.map((ex) => (
            <ExerciseCard
              key={ex.title}
              title={ex.title}
              description={ex.description}
              onStart={incrementStreak}
            />
          ))}
        </section>

        <section>
          <VoiceFeedback />
        </section>

        <footer className="text-center text-xs text-gray-400 pt-4">
          {config.appName} · Support: {config.supportContact.whatsapp}
        </footer>
      </main>
    </div>
  );
}

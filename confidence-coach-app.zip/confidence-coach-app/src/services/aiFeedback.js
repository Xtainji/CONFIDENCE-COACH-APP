// 🤖 AI Feedback Service
// Sends the user's transcript to our backend serverless function
// (api/feedback.js), which securely calls the Anthropic API.
// The API key is NEVER exposed to the browser — it stays server-side.

export async function getAIFeedback(transcript) {
  const response = await fetch("/api/feedback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ transcript }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    throw new Error(
      `AI feedback request failed (${response.status}): ${errText || "Unknown error"}`
    );
  }

  return response.json(); // { clarity, tone, confidence, tip }
}

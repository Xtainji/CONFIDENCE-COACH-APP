/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        brandPrimary: "var(--brand-primary)",
        brandSecondary: "var(--brand-secondary)",
      },
    },
  },
  plugins: [],
}

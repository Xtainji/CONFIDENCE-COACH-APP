Place your logo here as logo.png (see src/config.js)
